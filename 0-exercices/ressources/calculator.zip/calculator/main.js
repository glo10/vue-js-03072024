const { createApp } = Vue
createApp({
  data () {
    return {
      nb1: 10,
      nb2 : 30
    }
  },
  computed () {
    sum : () => {
      return this.nb1 + this.nb2
    }
  }
}).mount('#app')